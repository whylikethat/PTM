﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Sheets.v4;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.IO;
using Google.Apis.Sheets.v4.Data;
using System.Net;
using System.Net.Mail;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Personal_Task_Management
{
    public partial class editTask : Form
    {
        private static readonly string[] Scopes = { SheetsService.Scope.Spreadsheets };
        private static string ApplicationName = "Personal Task Manager";
        private static string SpreadsheetId = "YOUR_GOOGLE_SHEET_ID"; // Replace with your Google Sheet ID
        private static string SheetName = "YOUR_GOOGLE_SHEET_NAME"; // Adjust if needed
        private static string CredentialPath = "YOUR_CREDENTIALS.json"; // Adjust the path

        public string TaskName { get; set; }
        public string Priority { get; set; }
        public string Description { get; set; }
        public string ContactEmail { get; set; }

        private viewTask parentForm;

        public editTask(viewTask parent, string taskName, string priority, string description, string contactEmail)
        {
            InitializeComponent();

            this.parentForm = parent;

            // Initialize the form fields with the passed data
            taskNameTextBox.Text = taskName;
            priorityComboBox.SelectedItem = priority;
            descriptionTextBox.Text = description;
            contactEmailTextBox.Text = contactEmail;

            TaskName = taskName;
            Priority = priority;
            Description = description;
            ContactEmail = contactEmail;

            this.TaskName = taskName;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Save the edited data back into the properties
            TaskName = taskNameTextBox.Text;
            Priority = priorityComboBox.SelectedItem.ToString();
            Description = descriptionTextBox.Text;
            ContactEmail = contactEmailTextBox.Text;

            // Close the form after saving
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void saveChanges_Click(object sender, EventArgs e)
        {
            // Retrieve the edited values
            string newPriority = priorityComboBox.SelectedItem.ToString();
            string newDescription = descriptionTextBox.Text;
            string newContactEmail = contactEmailTextBox.Text;

            if (parentForm != null)
            {
                parentForm.UpdateTaskInGridAndGoogleSheet(TaskName, newPriority, newDescription, newContactEmail);
                MessageBox.Show("Changes saved!");
                parentForm.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Parent form reference is missing.");
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            viewTask goToViewTask = new viewTask();
            if (this.WindowState == FormWindowState.Maximized)
            {
                goToViewTask.WindowState = FormWindowState.Maximized;
                goToViewTask.Show();
                this.Hide();
            }
            else
            {
                goToViewTask.Show();
                this.Hide();
            }
        }
    }

}
