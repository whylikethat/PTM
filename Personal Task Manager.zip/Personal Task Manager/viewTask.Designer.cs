﻿namespace Personal_Task_Management
{
    partial class viewTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewTask));
            this.addButton = new System.Windows.Forms.Button();
            this.addPic = new System.Windows.Forms.PictureBox();
            this.addAuthorURL = new System.Windows.Forms.LinkLabel();
            this.dataGridViewTasks = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.addPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTasks)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // addButton
            // 
            this.addButton.FlatAppearance.BorderSize = 0;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.ForeColor = System.Drawing.Color.White;
            this.addButton.Location = new System.Drawing.Point(24, 85);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(189, 43);
            this.addButton.TabIndex = 1;
            this.addButton.Text = "Add Task";
            this.addButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // addPic
            // 
            this.addPic.Image = ((System.Drawing.Image)(resources.GetObject("addPic.Image")));
            this.addPic.Location = new System.Drawing.Point(35, 77);
            this.addPic.Name = "addPic";
            this.addPic.Size = new System.Drawing.Size(63, 51);
            this.addPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.addPic.TabIndex = 4;
            this.addPic.TabStop = false;
            this.addPic.Click += new System.EventHandler(this.addPic_Click);
            // 
            // addAuthorURL
            // 
            this.addAuthorURL.AutoSize = true;
            this.addAuthorURL.LinkColor = System.Drawing.Color.White;
            this.addAuthorURL.Location = new System.Drawing.Point(13, 167);
            this.addAuthorURL.Name = "addAuthorURL";
            this.addAuthorURL.Size = new System.Drawing.Size(210, 13);
            this.addAuthorURL.TabIndex = 5;
            this.addAuthorURL.TabStop = true;
            this.addAuthorURL.Text = "\"Icon made by srip from www.flaticon.com\"";
            this.addAuthorURL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.addAuthorURL_LinkClicked);
            // 
            // dataGridViewTasks
            // 
            this.dataGridViewTasks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewTasks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTasks.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewTasks.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridViewTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTasks.Location = new System.Drawing.Point(257, 3);
            this.dataGridViewTasks.Name = "dataGridViewTasks";
            this.dataGridViewTasks.ReadOnly = true;
            this.dataGridViewTasks.Size = new System.Drawing.Size(1150, 820);
            this.dataGridViewTasks.TabIndex = 6;
            this.dataGridViewTasks.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.addPic);
            this.panel1.Controls.Add(this.addButton);
            this.panel1.Controls.Add(this.addAuthorURL);
            this.panel1.Location = new System.Drawing.Point(12, 254);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 221);
            this.panel1.TabIndex = 7;
            // 
            // viewTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.ClientSize = new System.Drawing.Size(1409, 811);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridViewTasks);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "viewTask";
            this.Text = "Tasks";
            this.Load += new System.EventHandler(this.viewTask_Load);
            ((System.ComponentModel.ISupportInitialize)(this.addPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTasks)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.PictureBox addPic;
        private System.Windows.Forms.LinkLabel addAuthorURL;
        private System.Windows.Forms.DataGridView dataGridViewTasks;
        private System.Windows.Forms.Panel panel1;
    }
}

