﻿namespace Personal_Task_Management
{
    partial class addTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addTask));
            this.addTop = new System.Windows.Forms.TextBox();
            this.viewButton = new System.Windows.Forms.Button();
            this.viewPic = new System.Windows.Forms.PictureBox();
            this.viewURL = new System.Windows.Forms.LinkLabel();
            this.taskName = new System.Windows.Forms.TextBox();
            this.priority = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.taskDesc = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.emailText = new System.Windows.Forms.TextBox();
            this.contactEmail = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.viewPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // addTop
            // 
            this.addTop.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.addTop.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.addTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addTop.ForeColor = System.Drawing.SystemColors.Info;
            this.addTop.Location = new System.Drawing.Point(672, 2);
            this.addTop.Name = "addTop";
            this.addTop.Size = new System.Drawing.Size(132, 31);
            this.addTop.TabIndex = 0;
            this.addTop.TabStop = false;
            this.addTop.Text = "Add Task";
            this.addTop.TextChanged += new System.EventHandler(this.addTop_TextChanged);
            // 
            // viewButton
            // 
            this.viewButton.FlatAppearance.BorderSize = 0;
            this.viewButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewButton.ForeColor = System.Drawing.Color.White;
            this.viewButton.Location = new System.Drawing.Point(87, 77);
            this.viewButton.Name = "viewButton";
            this.viewButton.Size = new System.Drawing.Size(198, 40);
            this.viewButton.TabIndex = 1;
            this.viewButton.Text = "View Tasks";
            this.viewButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.viewButton.UseVisualStyleBackColor = true;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click);
            // 
            // viewPic
            // 
            this.viewPic.Image = ((System.Drawing.Image)(resources.GetObject("viewPic.Image")));
            this.viewPic.Location = new System.Drawing.Point(87, 67);
            this.viewPic.Name = "viewPic";
            this.viewPic.Size = new System.Drawing.Size(63, 50);
            this.viewPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.viewPic.TabIndex = 2;
            this.viewPic.TabStop = false;
            this.viewPic.Click += new System.EventHandler(this.viewPic_Click);
            // 
            // viewURL
            // 
            this.viewURL.AutoSize = true;
            this.viewURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewURL.LinkColor = System.Drawing.Color.White;
            this.viewURL.Location = new System.Drawing.Point(48, 164);
            this.viewURL.Name = "viewURL";
            this.viewURL.Size = new System.Drawing.Size(237, 13);
            this.viewURL.TabIndex = 3;
            this.viewURL.TabStop = true;
            this.viewURL.Text = "\"Icon made by juicy_fish from www.flaticon.com\"";
            this.viewURL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.viewURL_LinkClicked);
            // 
            // taskName
            // 
            this.taskName.Location = new System.Drawing.Point(336, 52);
            this.taskName.MaxLength = 32;
            this.taskName.Multiline = true;
            this.taskName.Name = "taskName";
            this.taskName.Size = new System.Drawing.Size(665, 33);
            this.taskName.TabIndex = 4;
            this.taskName.TextChanged += new System.EventHandler(this.taskName_TextChanged);
            // 
            // priority
            // 
            this.priority.BackColor = System.Drawing.Color.White;
            this.priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.priority.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.priority.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priority.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.priority.FormattingEnabled = true;
            this.priority.Items.AddRange(new object[] {
            "\tlow",
            "\tmedium",
            "\thigh"});
            this.priority.Location = new System.Drawing.Point(448, 148);
            this.priority.Name = "priority";
            this.priority.Size = new System.Drawing.Size(252, 24);
            this.priority.TabIndex = 5;
            this.priority.TabStop = false;
            this.priority.Tag = "priority";
            this.priority.SelectedIndexChanged += new System.EventHandler(this.priority_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.Info;
            this.textBox1.Location = new System.Drawing.Point(103, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(239, 36);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "Enter Task Name";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // taskDesc
            // 
            this.taskDesc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.taskDesc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.taskDesc.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taskDesc.ForeColor = System.Drawing.SystemColors.Info;
            this.taskDesc.Location = new System.Drawing.Point(-12, 219);
            this.taskDesc.Name = "taskDesc";
            this.taskDesc.Size = new System.Drawing.Size(1013, 39);
            this.taskDesc.TabIndex = 7;
            this.taskDesc.Text = "Enter a description of the task. (What to do)";
            this.taskDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(52, 265);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(949, 251);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // emailText
            // 
            this.emailText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.emailText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailText.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailText.ForeColor = System.Drawing.SystemColors.Info;
            this.emailText.Location = new System.Drawing.Point(168, 564);
            this.emailText.Name = "emailText";
            this.emailText.Size = new System.Drawing.Size(274, 36);
            this.emailText.TabIndex = 10;
            this.emailText.Text = "Enter contact e-mail";
            this.emailText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.emailText.TextChanged += new System.EventHandler(this.emailText_TextChanged);
            // 
            // contactEmail
            // 
            this.contactEmail.Location = new System.Drawing.Point(448, 567);
            this.contactEmail.MaxLength = 50;
            this.contactEmail.Multiline = true;
            this.contactEmail.Name = "contactEmail";
            this.contactEmail.Size = new System.Drawing.Size(530, 33);
            this.contactEmail.TabIndex = 11;
            this.contactEmail.TextChanged += new System.EventHandler(this.contactEmail_TextChanged);
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.submitButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.submitButton.FlatAppearance.BorderSize = 0;
            this.submitButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.ForeColor = System.Drawing.SystemColors.Info;
            this.submitButton.Location = new System.Drawing.Point(351, 678);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(125, 36);
            this.submitButton.TabIndex = 12;
            this.submitButton.Text = "ADD";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.Color.Red;
            this.cancelButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.ForeColor = System.Drawing.SystemColors.Info;
            this.cancelButton.Location = new System.Drawing.Point(555, 678);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(125, 36);
            this.cancelButton.TabIndex = 13;
            this.cancelButton.Text = "CLEAR";
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.cancelButton);
            this.panel1.Controls.Add(this.taskName);
            this.panel1.Controls.Add(this.submitButton);
            this.panel1.Controls.Add(this.priority);
            this.panel1.Controls.Add(this.contactEmail);
            this.panel1.Controls.Add(this.taskDesc);
            this.panel1.Controls.Add(this.emailText);
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Location = new System.Drawing.Point(362, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1047, 811);
            this.panel1.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.viewPic);
            this.panel2.Controls.Add(this.viewButton);
            this.panel2.Controls.Add(this.viewURL);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.panel2.Location = new System.Drawing.Point(12, 265);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(342, 207);
            this.panel2.TabIndex = 15;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.SystemColors.Info;
            this.textBox2.Location = new System.Drawing.Point(300, 144);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 28);
            this.textBox2.TabIndex = 14;
            this.textBox2.TabStop = false;
            this.textBox2.Text = "Select Priority";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // addTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.ClientSize = new System.Drawing.Size(1409, 811);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.addTop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "addTask";
            this.Text = "Add Task";
            this.Load += new System.EventHandler(this.addTask_Load);
            ((System.ComponentModel.ISupportInitialize)(this.viewPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox addTop;
        private System.Windows.Forms.Button viewButton;
        private System.Windows.Forms.PictureBox viewPic;
        private System.Windows.Forms.LinkLabel viewURL;
        private System.Windows.Forms.TextBox taskName;
        private System.Windows.Forms.ComboBox priority;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox taskDesc;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox emailText;
        private System.Windows.Forms.TextBox contactEmail;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox2;
    }
}