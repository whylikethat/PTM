﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Sheets.v4;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.IO;
using Google.Apis.Sheets.v4.Data;
using System.Text.RegularExpressions;


namespace Personal_Task_Management

{
    public partial class addTask : Form
    {
        private static readonly string[] Scopes = { SheetsService.Scope.Spreadsheets };
        private static string ApplicationName = "Personal Task Manager";
        private static string SpreadsheetId = "YOUR_GOOGLE_SHEET_ID"; // Replace with your Google Sheet ID
        private static string SheetName = "YOUR_SHEET_NAME"; // Adjust if needed
        private static string CredentialPath = "CREDENTIAL_FILE.JSON"; // Adjust the path
        public string name, priorityValue, description, email;

        public addTask()
        {
            InitializeComponent();
        }

        // Email validation method using Regex
        private bool IsValidEmail(string email)
        {
            // Regular expression for validating email
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(pattern);

            return regex.IsMatch(email);
        }

        private void WriteToGoogleSheet(string taskName, string priority, string description, string contactEmail)
        {
            try
            {
                GoogleCredential credential;
                using (var stream = new FileStream(CredentialPath, FileMode.Open, FileAccess.Read))
                {
                    credential = GoogleCredential.FromStream(stream).CreateScoped(Scopes);
                }

                var service = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = ApplicationName,
                });

                var range = $"{SheetName}!A:D"; // Columns A to D
                var rowData = new List<object> { taskName, priority, description, contactEmail };
                var valueRange = new ValueRange { Values = new List<IList<object>> { rowData } };

                var appendRequest = service.Spreadsheets.Values.Append(valueRange, SpreadsheetId, range);
                appendRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum.USERENTERED;
                appendRequest.InsertDataOption = SpreadsheetsResource.ValuesResource.AppendRequest.InsertDataOptionEnum.INSERTROWS;
                appendRequest.Execute();

                MessageBox.Show("Task added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            viewTask goToViewTask = new viewTask();
            if (this.WindowState == FormWindowState.Maximized) { 
                goToViewTask.WindowState = FormWindowState.Maximized;
                goToViewTask.Show();
                this.Hide();
            }
            else
            {
                goToViewTask.Show();
                this.Hide();
            }
        }

        private void viewPic_Click(object sender, EventArgs e)
        {
            viewTask goToViewTask = new viewTask();
            if (this.WindowState == FormWindowState.Maximized)
            {
                goToViewTask.WindowState = FormWindowState.Maximized;
                goToViewTask.Show();
                this.Hide();
            }
            else
            {
                goToViewTask.Show();
                this.Hide();
            }
        }

        private void addTop_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void viewURL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.flaticon.com/authors/juicy-fish");
        }

        private void taskName_TextChanged(object sender, EventArgs e)
        {
            name = taskName.Text;
        }

        private void priority_SelectedIndexChanged(object sender, EventArgs e)
        {
            priorityValue = priority.SelectedItem.ToString();
        }

        private void contactEmail_TextChanged(object sender, EventArgs e)
        {
            email = contactEmail.Text;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            description = richTextBox1.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void addTask_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailText_TextChanged(object sender, EventArgs e)
        {

        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            addTask goToAddTask = new addTask();
            if (this.WindowState == FormWindowState.Maximized)
            {
                goToAddTask.WindowState = FormWindowState.Maximized;
                goToAddTask.Show();
                this.Hide();
            }
            else
            {
                goToAddTask.Show();
                this.Hide();
            }
        }

        private void submitButton_Click(object sender, EventArgs e)

        {
            if (taskName.Text == "")
            {
                errorProvider1.SetError(taskName, "This field is required.");
            }
            else if (string.IsNullOrEmpty(email) || !IsValidEmail(email))
            {
                errorProvider1.SetError(contactEmail, "Please enter a valid email address.");
            } 
            else
            {
                WriteToGoogleSheet(name, priorityValue, description, email);
                viewTask gonow = new viewTask();
                gonow.Show();
                this.Close();
            }
        }
    }
}
