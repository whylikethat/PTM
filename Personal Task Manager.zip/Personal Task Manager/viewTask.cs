﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Sheets.v4;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.IO;
using Google.Apis.Sheets.v4.Data;
using System.Net;
using System.Net.Mail;

namespace Personal_Task_Management
{
    public partial class viewTask : Form
    {
        private static readonly string[] Scopes = { SheetsService.Scope.Spreadsheets };
        private static string ApplicationName = "Personal Task Manager";
        private static string SpreadsheetId = "YOUR_GOOGLE_SHEET_ID"; // Replace with your Google Sheet ID
        private static string SheetName = "YOUR_SHEET_NAME"; // Adjust if needed
        private static string CredentialPath = "YOUR_CREDENTIALS.json"; // Adjust the path
        

        public viewTask()
        {
            InitializeComponent();
            LoadGoogleSheetData();
        }

        public void UpdateTaskInGridAndGoogleSheet(string taskName, string newPriority, string newDescription, string newContactEmail)
        {
            // 1. Update the DataGridView
            foreach (DataGridViewRow row in dataGridViewTasks.Rows)
            {
                if (row.Cells[0].Value.ToString() == taskName)  // Assuming taskName is in column A
                {
                    row.Cells[1].Value = newPriority;   // Update Priority
                    row.Cells[2].Value = newDescription; // Update Description
                    row.Cells[3].Value = newContactEmail; // Update Contact Email
                    break;
                }
            }

            // 2. Update the Google Sheet
            try
            {
                GoogleCredential credential;
                using (var stream = new FileStream(CredentialPath, FileMode.Open, FileAccess.Read))
                {
                    credential = GoogleCredential.FromStream(stream).CreateScoped(Scopes);
                }
                var service = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = ApplicationName
                });

                // Find the row in the Google Sheet to update
                var range = $"{SheetName}!A:D";  // Assuming you're updating columns A to D
                var request = service.Spreadsheets.Values.Get(SpreadsheetId, range);
                var response = request.Execute();

                var values = response.Values;
                if (values != null)
                {
                    foreach (var row in values)
                    {
                        if (row[0].ToString() == taskName) // Match taskName in column A
                        {
                            int rowIndex = values.IndexOf(row) + 1; // Google Sheets uses 1-based index

                            // Prepare the updated row data
                            var updateValues = new List<object>
                    {
                        taskName,
                        newPriority,
                        newDescription,
                        newContactEmail
                    };

                            // Update the Google Sheet
                            var updateRange = $"{SheetName}!A{rowIndex}:D{rowIndex}";
                            var updateValueRange = new ValueRange
                            {
                                Values = new List<IList<object>> { updateValues }
                            };

                            var updateRequest = service.Spreadsheets.Values.Update(updateValueRange, SpreadsheetId, updateRange);
                            updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
                            updateRequest.Execute();
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Google Sheet: " + ex.Message);
            }
        }


        // Method to send email notification (You must enable the call to this function down below)
        private void SendDeleteNotificationEmail(string taskName, string taskDescription, string contactEmail)
        {
            try
            {
                // SMTP client setup (Example for Gmail, you can adjust for other providers)
                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("youremail@gmail.com", "yourpassword"), // Replace with your credentials
                    EnableSsl = true,
                };

                // Create email message
                var mailMessage = new MailMessage
                {
                    From = new MailAddress("youremail@gmail.com"), // Replace with your email
                    Subject = taskName, // Set subject as task name
                    Body = taskDescription + "\r\n\r\nTask Complete!", // Set body as task description
                    IsBodyHtml = false, // Set to false for plain text email
                };

                mailMessage.To.Add(contactEmail); // Add the recipient email

                // Send email
                smtpClient.Send(mailMessage);
                MessageBox.Show("Notification email sent successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending email: " + ex.Message);
            }
        }

        private void LoadGoogleSheetData()
        {
            try
            {
                GoogleCredential credential;
                using (var stream = new FileStream(CredentialPath, FileMode.Open, FileAccess.Read))
                {
                    credential = GoogleCredential.FromStream(stream).CreateScoped(Scopes);
                }

                var service = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = ApplicationName,
                });

                var range = $"{SheetName}!A2:D"; // Read from A2 to D (adjust the range if necessary)
                var request = service.Spreadsheets.Values.Get(SpreadsheetId, range);

                // Execute the request to fetch data
                var response = request.Execute();
                var values = response.Values;

                if (values != null && values.Count > 0)
                {
                    // Add columns for Edit and Delete buttons
                    dataGridViewTasks.ColumnCount = 5;  // Adding one more column for buttons
                    dataGridViewTasks.Columns[0].Name = "Task Name";
                    dataGridViewTasks.Columns[1].Name = "Priority";
                    dataGridViewTasks.Columns[2].Name = "Description";
                    dataGridViewTasks.Columns[3].Name = "Contact E-mail";
                    dataGridViewTasks.Columns[4].Name = "Actions";  // This column will hold buttons

                    // Add data to the grid and add buttons for each row
                    foreach (var row in values)
                    {
                        var index = dataGridViewTasks.Rows.Add(row.ToArray());

                        // Add Edit and Delete buttons to the last column
                        var editButton = new DataGridViewButtonCell();
                        var deleteButton = new DataGridViewButtonCell();

                        editButton.Value = "Edit";
                        deleteButton.Value = "Delete";

                        dataGridViewTasks.Rows[index].Cells[4] = editButton;  // Actions column for buttons

                        // Handle button clicks
                        dataGridViewTasks.CellClick += (sender, e) =>
                        {
                            if (e.RowIndex >= 0 && e.ColumnIndex == 4) // Check if the button clicked is in the Action column
                            {
                                if (dataGridViewTasks.Rows[e.RowIndex].Cells[4].Value.ToString() == "Edit")
                                {
                                    // Open edit form and pass data to it
                                    string taskName = dataGridViewTasks.Rows[e.RowIndex].Cells[0].Value.ToString();
                                    string priority = dataGridViewTasks.Rows[e.RowIndex].Cells[1].Value.ToString();
                                    string description = dataGridViewTasks.Rows[e.RowIndex].Cells[2].Value.ToString();
                                    string contactEmail = dataGridViewTasks.Rows[e.RowIndex].Cells[3].Value.ToString();

                                    // Open the Edit form (you can create this form later)
                                    editTask editForm = new editTask(this, taskName, priority, description, contactEmail);
                                    editForm.ShowDialog();

                                    // After editing, reload the data
                                    dataGridViewTasks.Rows.Clear();
                                    LoadGoogleSheetData();
                                }
                                else if (dataGridViewTasks.Rows[e.RowIndex].Cells[4].Value.ToString() == "Delete")
                                {
                                    // Get the task details from the row
                                    string taskName = dataGridViewTasks.Rows[e.RowIndex].Cells[0].Value.ToString();

                                    // Call a method to delete from Google Sheets and refresh grid
                                    DeleteRowFromGoogleSheet(taskName);
                                    dataGridViewTasks.Rows.RemoveAt(e.RowIndex); // Remove row from grid
                                }
                            }
                        };
                    }

                    foreach (DataGridViewRow row in dataGridViewTasks.Rows)
                    {
                        string priority = row.Cells[1].Value?.ToString().ToLower(); // Column index 1 is "Priority"

                        if (priority == "low")
                        {
                            row.Cells[1].Style.ForeColor = System.Drawing.Color.Green;
                        }
                        else if (priority == "medium")
                        {
                            row.Cells[1].Style.ForeColor = System.Drawing.Color.DarkOrange;
                        }
                        else if (priority == "high")
                        {
                            row.Cells[1].Style.ForeColor = System.Drawing.Color.Red;
                        }

                        // Optional: make priority text bold as well
                        row.Cells[1].Style.Font = new Font("Segoe UI", 12, FontStyle.Bold);
                    }
                }
                else
                {
                    // Display Add Task
                    System.Console.WriteLine("No Tasks. Add Task!");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        // Method to delete task from Google Sheets
        private void DeleteRowFromGoogleSheet(string taskName)
        {
            try
            {
                // Authenticate using credentials
                GoogleCredential credential;
                using (var stream = new FileStream(CredentialPath, FileMode.Open, FileAccess.Read))
                {
                    credential = GoogleCredential.FromStream(stream).CreateScoped(Scopes);
                }

                var service = new SheetsService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = ApplicationName,
                });

                var range = $"{SheetName}!A:D";  // Range for task data
                var request = service.Spreadsheets.Values.Get(SpreadsheetId, range);
                var response = request.Execute();

                var values = response.Values;
                if (values != null)
                {
                    foreach (var row in values)
                    {
                        if (row[0].ToString() == taskName)  // Assuming taskName is in column A (index 0)
                        {
                            int rowIndex = values.IndexOf(row);  // Google Sheets is 0-based, so no need to add 1

                            // Get the SheetId for the sheet where the task exists
                            int sheetId = GetSheetId(service);

                            // Create the DeleteDimensionRequest with the correct dimension
                            var deleteRequest = new Request()
                            {
                                DeleteDimension = new DeleteDimensionRequest()
                                {
                                    Range = new DimensionRange()
                                    {
                                        SheetId = sheetId,
                                        Dimension = "ROWS",  // Specify that we're working with rows
                                        StartIndex = rowIndex,  // Start of the row to delete
                                        EndIndex = rowIndex + 1  // End of the row to delete (exclusive)
                                    }
                                }
                            };

                            var batchUpdateRequest = new BatchUpdateSpreadsheetRequest()
                            {
                                Requests = new List<Request> { deleteRequest }
                            };

                            // Execute the batch update to delete the row
                            var batchUpdate = service.Spreadsheets.BatchUpdate(batchUpdateRequest, SpreadsheetId);
                            batchUpdate.Execute();

                            MessageBox.Show("Task Complete!");

                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting from Google Sheets: " + ex.Message);
            }
        }

        private int GetSheetId(SheetsService service)
        {
            var sheetRequest = service.Spreadsheets.Get(SpreadsheetId);
            var sheetResponse = sheetRequest.Execute();
            var sheet = sheetResponse.Sheets.FirstOrDefault(s => s.Properties.Title == SheetName);
            return sheet?.Properties.SheetId ?? 0;  // Return the SheetId (or 0 if not found)
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            addTask goToAddTask = new addTask();
            if(this.WindowState == FormWindowState.Maximized) {
                goToAddTask.WindowState = FormWindowState.Maximized;
                goToAddTask.Show();
                this.Hide();
            }
            else
            {
                goToAddTask.Show();
                this.Hide();
            }
            
        }

        private void addPic_Click(object sender, EventArgs e)
        {
            addTask goToAddTask = new addTask();
            if (this.WindowState == FormWindowState.Maximized)
            {
                goToAddTask.WindowState = FormWindowState.Maximized;
                goToAddTask.Show();
                this.Hide();
            }
            else
            {
                goToAddTask.Show();
                this.Hide();
            }
        }

        private void taskTop_TextChanged(object sender, EventArgs e)
        {

        }

        private void addAuthorURL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.flaticon.com/authors/srip");
        }

        private void viewTask_Load(object sender, EventArgs e)
        {
            InitializeDataGrid();

        }

        private void InitializeDataGrid()
{
            dataGridViewTasks.ColumnCount = 4;
            dataGridViewTasks.Columns[0].Name = "Task Name";
            dataGridViewTasks.Columns[1].Name = "Priority";
            dataGridViewTasks.Columns[2].Name = "Status";
            dataGridViewTasks.Columns[3].Name = "Contact E-mail";

            dataGridViewTasks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewTasks.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            // Styling: Fonts
            dataGridViewTasks.DefaultCellStyle.Font = new Font("Segoe UI", 12, FontStyle.Regular);
            dataGridViewTasks.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 18, FontStyle.Bold);

            // Styling: Colors
            dataGridViewTasks.BackgroundColor = System.Drawing.Color.White;
            dataGridViewTasks.GridColor = System.Drawing.Color.LightGray;
            dataGridViewTasks.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridViewTasks.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            dataGridViewTasks.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewTasks.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.Black;

            dataGridViewTasks.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.AliceBlue;
            dataGridViewTasks.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.SteelBlue;
            dataGridViewTasks.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;


            // Styling: Borders and alignment
            dataGridViewTasks.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewTasks.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewTasks.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // Misc
            dataGridViewTasks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewTasks.AllowUserToAddRows = false;
            dataGridViewTasks.EnableHeadersVisualStyles = false; // Allow custom header colors

            // EDIT BUTTON - dark gray
            DataGridViewButtonColumn editButtonColumn = new DataGridViewButtonColumn();
            editButtonColumn.Name = "Edit";
            editButtonColumn.HeaderText = "";
            editButtonColumn.Text = "✎ EDIT";
            editButtonColumn.UseColumnTextForButtonValue = true;
            editButtonColumn.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(44, 62, 80); // Dark bluish-gray
            editButtonColumn.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            editButtonColumn.DefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            editButtonColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewTasks.Columns.Add(editButtonColumn);

            // DELETE BUTTON - dark red
            DataGridViewButtonColumn deleteButtonColumn = new DataGridViewButtonColumn();
            deleteButtonColumn.Name = "Delete";
            deleteButtonColumn.HeaderText = "";
            deleteButtonColumn.Text = "✔️ COMPLETE";
            deleteButtonColumn.UseColumnTextForButtonValue = true;
            deleteButtonColumn.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(44, 62, 80); // Dark bluish-gray
            deleteButtonColumn.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            deleteButtonColumn.DefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            deleteButtonColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewTasks.Columns.Add(deleteButtonColumn);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string taskName = dataGridViewTasks.Rows[e.RowIndex].Cells[0].Value.ToString();

                if (dataGridViewTasks.Columns[e.ColumnIndex].Name == "Edit")
                {
                    // 👇 You'll open a new form here for editing
                    string priority = dataGridViewTasks.Rows[e.RowIndex].Cells[1].Value.ToString();
                    string description = dataGridViewTasks.Rows[e.RowIndex].Cells[2].Value.ToString();
                    string contactEmail = dataGridViewTasks.Rows[e.RowIndex].Cells[3].Value.ToString();
                    editTask editForm = new editTask(this, taskName, priority, description, contactEmail);
                    editForm.Show();
                    this.Hide();

                }
                else if (dataGridViewTasks.Columns[e.ColumnIndex].Name == "Delete")
                {
                    // Get the description and contact email from the respective columns in the grid
                    //SendDeleteNotificationEmail(taskName, dataGridViewTasks.Rows[e.RowIndex].Cells[2].Value.ToString(), dataGridViewTasks.Rows[e.RowIndex].Cells[3].Value.ToString());
                    //Enable the line above once you have setup your SMTP credentials

                    DialogResult result = MessageBox.Show(
                        "Are you sure you want to complete this task?",
                        "Confirm Complete",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning
                    );

                    if (result == DialogResult.Yes)
                    {
                        // 👇 Call a function to delete from Google Sheets
                        DeleteRowFromGoogleSheet(taskName); 

                        // Remove from grid
                        dataGridViewTasks.Rows.RemoveAt(e.RowIndex);
                    }
                }
            }
        }
    }
}
